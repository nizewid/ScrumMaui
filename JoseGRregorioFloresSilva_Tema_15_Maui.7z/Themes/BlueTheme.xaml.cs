namespace ScrumMaui.Themes;

public partial class BlueTheme : ResourceDictionary
{
	public BlueTheme()
	{
		InitializeComponent();
	}
}