namespace ScrumMaui.Themes;

public partial class WhiteTheme : ResourceDictionary
{
	public WhiteTheme()
	{
		InitializeComponent();
	}
}