namespace ScrumMaui.Views.Spring;

public partial class Daily : ContentPage
{
	public Daily()
	{
		InitializeComponent();
	}
}