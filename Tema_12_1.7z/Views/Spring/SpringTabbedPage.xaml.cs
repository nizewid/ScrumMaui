namespace ScrumMaui.Views.Spring;

public partial class SpringTabbedPage : TabbedPage
{
	public SpringTabbedPage()
	{
		InitializeComponent();
	}
}