namespace ScrumMaui.Views.User;

public partial class UserPage : ContentPage
{
	public UserPage()
	{
		InitializeComponent();
	}
}