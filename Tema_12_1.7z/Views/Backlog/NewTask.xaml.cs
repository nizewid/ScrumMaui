namespace ScrumMaui.Views.Backlog;

public partial class NewTask : ContentPage
{
	public NewTask()
	{
		InitializeComponent();
	}
}