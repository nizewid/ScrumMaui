namespace ScrumMaui.Views.User;

public partial class UserTabbedPage : TabbedPage
{
	public UserTabbedPage()
	{
		InitializeComponent();
	}
}