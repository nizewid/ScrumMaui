﻿using Microsoft.AspNetCore.Authentication;

namespace MauiApis.Services
{
    public class SessionTokenAuthSchemeOptions : AuthenticationSchemeOptions
    {
        public bool MyOption { get; set; }
    }
}
