﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Options;
using System.Security.Claims;
using System.Text.Encodings.Web;

namespace MauiApis.Services
{
    public class SessionTokenAuthSchemeHandler : AuthenticationHandler<SessionTokenAuthSchemeOptions>
    {
        private readonly TokenService tokenService = new TokenService();
        private readonly string key = "En un lugar de la mancha de cuyo nombre no quiero acordarme no ha mucho que vivía un hidalgo de los de lanza en astillero adarga";

        public SessionTokenAuthSchemeHandler(
            IOptionsMonitor<SessionTokenAuthSchemeOptions> options,
            ILoggerFactory logger,
            UrlEncoder encoder)
            : base(options, logger, encoder)
        {
        }

        protected async override Task<AuthenticateResult> HandleAuthenticateAsync()
        {
            // Read the token from request headers/cookies  
            // Check that it's a valid session, depending on your implementation  
            string barerToken = Context.Request.Headers["Authorization"];
            bool isAuthenticated = true;
            if (!string.IsNullOrEmpty(barerToken))
            {
                barerToken = barerToken.Replace("Bearer ", "");
                isAuthenticated = tokenService.IsTokenValid(key, "https://localhost:7160/", barerToken);
            }

            // If the session is valid, return success:  
            if (isAuthenticated)
            {
                var claims = new[] { new Claim(ClaimTypes.Name, "Test") };
                var principal = new ClaimsPrincipal(new ClaimsIdentity(claims, "Tokens"));
                var ticket = new AuthenticationTicket(principal, this.Scheme.Name);
                return AuthenticateResult.Success(ticket);
            }
            else
            {
                // If the token is missing or the session is invalid, return failure:  
                return AuthenticateResult.Fail("Authentication failed");
            }
        }
    }
}
