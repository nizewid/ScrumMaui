﻿using MauiApis.Models;

namespace MauiApis.Repositories
{
    public interface IUserRepository
    {
        UserDTO GetUser(UserModel userModel);
    }
}
