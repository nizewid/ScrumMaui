﻿using MauiApis.Models;

namespace MauiApis.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly List<UserDTO> users = new List<UserDTO>();
        public UserRepository()
        {
            users.Add(new UserDTO { UserName = "julian", Password = "ebro123", Role = "manager" });
            users.Add(new UserDTO { UserName = "rosamatas", Password = "tajo123", Role = "developer" });
            users.Add(new UserDTO { UserName = "mariamartin", Password = "guadiana123", Role = "tester" });
            users.Add(new UserDTO { UserName = "rodolfo", Password = "guadalquivir123", Role = "admin" });
            users.Add(new UserDTO { UserName = "juan", Password = "duero123", Role = "admin" });
            users.Add(new UserDTO { UserName = "josegregorio", Password = "123456", Role = "admin" });
        }
        public UserDTO GetUser(UserModel userModel)
        {
            return users.Where(x => x.UserName.ToLower() == userModel.UserName.ToLower()
                && x.Password == userModel.Password).FirstOrDefault();
        }
    }
}

