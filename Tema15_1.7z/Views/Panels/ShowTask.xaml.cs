namespace ScrumMaui.Views.Panels;

public partial class ShowTask : ContentPage
{
	public ShowTask()
	{
		InitializeComponent();
	}
}