namespace ScrumMaui.Views.Backlog;

public partial class BacklogTabbedPage : TabbedPage
{
	public BacklogTabbedPage()
	{
		InitializeComponent();
	}
}