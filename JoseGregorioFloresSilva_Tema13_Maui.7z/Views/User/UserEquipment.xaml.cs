namespace ScrumMaui.Views.User;

public partial class UserEquipment : ContentPage
{
	public UserEquipment()
	{
		InitializeComponent();
	}
}