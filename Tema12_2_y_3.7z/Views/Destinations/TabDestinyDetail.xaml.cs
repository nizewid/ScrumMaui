namespace MauiPlanTurismo.Views.Destinations;

public partial class TabDestinyDetail : ContentPage
{
	public TabDestinyDetail()
	{
		InitializeComponent();
	}
}