namespace MauiPlanTurismo.Views.Destinations;

public partial class TabDestiny
{
	public TabDestiny()
	{
		InitializeComponent();
	}
}