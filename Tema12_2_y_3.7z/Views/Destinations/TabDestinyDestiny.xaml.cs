namespace MauiPlanTurismo.Views.Destinations;

public partial class TabDestinyDestiny : ContentPage
{
	public TabDestinyDestiny()
	{
		InitializeComponent();
	}
}