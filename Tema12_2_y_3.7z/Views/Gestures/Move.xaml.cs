namespace MauiPlanTurismo.Views.Gestures;

public partial class Move : ContentPage
{
	public Move()
	{
		InitializeComponent();
	}
}