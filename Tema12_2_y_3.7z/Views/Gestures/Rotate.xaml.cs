namespace MauiPlanTurismo.Views.Gestures;

public partial class Rotate : ContentPage
{
	public Rotate()
	{
		InitializeComponent();
	}
}