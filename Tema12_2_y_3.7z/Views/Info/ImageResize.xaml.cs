namespace MauiPlanTurismo.Views.Info;

public partial class ImageResize : ContentPage
{
	public ImageResize()
	{
		InitializeComponent();
	}
}