namespace MauiPlanTurismo.Views.Options;

public partial class DestinationsOptions : TabbedPage
{
	public DestinationsOptions()
	{
		InitializeComponent();
	}
}