namespace MauiPlanTurismo.Views.Travel;

public partial class TravelRequest : ContentPage
{
	public TravelRequest()
	{
		InitializeComponent();
	}
}