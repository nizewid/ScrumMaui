﻿using MauiApis.Models;
using Microsoft.AspNetCore.Mvc;
using ScrumMaui.Data;
using System.Diagnostics;
using System.Formats.Tar;
using System.Threading;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace MauiApis.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ScrumController : ControllerBase
    {
        // GET: api/<ScrumController>
        [HttpGet]
        public IEnumerable<TaskModel> Get()
        {
            return ScrumData.TaskList;
        }

        // GET api/<ScrumController>/5
        [HttpGet("{id}")]
        public TaskModel Get(int id)
        {
            TaskModel? task = ScrumData.TaskList.Find(x => x.Id == id);
            if (task == null)
            {
                task = new TaskModel() ;
            }
            return task;
        }

        // POST api/<ScrumController>
        [HttpPost]
        public void Post([FromBody] TaskModel task)
        {
            try
            {
                if (task != null)
                {
                    task.Id = ScrumData.TaskList.Max(x => x.Id) + 1;
                    ScrumData.TaskList.Add(task);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
        }

        // PUT api/<ScrumController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] TaskModel task)
        {
            try
            {
                if (task != null)
                {
                    TaskModel? currentTask = ScrumData.TaskList.Find(x => x.Id == id);
                    if (currentTask == null)
                    {
                        currentTask.Name = task.Name;
                        currentTask.Description = task.Description;
                        currentTask.ParentTaskName = task.ParentTaskName;
                        currentTask.AssignedDate = task.AssignedDate;
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
        }

        // DELETE api/<ScrumController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            try
            {
                TaskModel taskDelete = ScrumData.TaskList.Where(x => x.Id == id).FirstOrDefault();
                if (taskDelete != null)
                {
                    ScrumData.TaskList.Remove(taskDelete);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
        }
    }
}
