﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MauiApis.Models
{
    public class TaskModel
    {
        public int Id { get; set; }
        public string? TaskCode { get; set; }
        public string? TaskType { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public string? ParentTaskCode { get; set; }
        public string? ParentTaskName { get; set; }
        public string? Status { get; set; }
        public DateTime? PlannedDate { get; set; }
        public DateTime? AssignedDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string? PlannedDateText { get; set; }
        public string? AssignedDateText { get; set; }
        public string? EndDateText { get; set; }
        public string? AssignedUser { get; set; }
        public string? Notes { get; set; }
        public string? TypeIcon { get; set; }
        public string? Avatar { get; set; }
    }
}
